<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Categories        Alexa Skills  _59be89</name>
   <tag></tag>
   <elementGuidId>f095f19d-b9b5-4ee2-97bd-4e53b836da79</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>1663cf59-c175-440f-9a2f-c4ee97a0e473</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>c7092402-5f9f-4326-bf66-b1faa7aa6b9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>4a5ba9da-5cac-490b-9ef4-ee209a2628e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>yEUBJoU3pm/EETBZjEB+fZs46n4=</value>
      <webElementGuid>e372f8e3-f18d-4fce-ae78-a20ac6938c57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>f8e51e78-5f11-4684-8ac4-b61b1ca58ce5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>24dd4a1a-d26f-42c4-8128-cf9bcc856585</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>43e1ebba-2892-4171-ac4c-cc5a67c60968</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>2dbd4414-33bf-453d-884b-0ee008a39bda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>5a5ef531-b080-417a-b2f3-a66fc5810966</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    </value>
      <webElementGuid>50ca4909-13f2-485d-970d-f8d2f857b4d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>85e85aa1-cb5a-4fd4-bb4e-b451f3cf5462</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>934738b9-a16a-46a5-a41c-b1d67cecc207</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>038a7e7f-dc76-43a1-98c4-f1866188e350</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>c1954538-4b53-4365-b47f-b0841fb2e28d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ' or . = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ')]</value>
      <webElementGuid>3288ccf0-fbc6-4d97-90db-12056daa2e85</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
